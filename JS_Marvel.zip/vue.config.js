module.exports = {
  pwa: {
    name: 'marvel',
    themeColor: '#212121'
  }
}